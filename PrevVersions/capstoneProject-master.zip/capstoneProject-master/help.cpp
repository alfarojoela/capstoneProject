#include "help.hpp"

void help()
{
std::cout << "Game commands: " << std::endl;
std::cout << "attack, break, drink, drop, eat," << std::endl;
std::cout << "flee, go, help, inventory, jump," << std::endl;
std::cout <<"look, look at, smell, take, talk, use" << std::endl;
}


