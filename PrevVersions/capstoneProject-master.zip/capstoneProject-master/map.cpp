#include "map.hpp"

void map()
{
std::cout << "Map: " << std::endl;



std::cout <<"			|-------|		|-----------------|		|--------------|	|--------|"<< std::endl;
std::cout <<"			|Latrine|		|MacReady Quarters|		|Equipment Room|--------|Toolshed|"<< std::endl;
std::cout <<"			|-------|		|-----------------|		|--------------|	|--------|" << std::endl;
std::cout <<"				|			|				|		" << std::endl;
std::cout <<"				|			|				|		" << std::endl;
std::cout <<"				|			|				|		" << std::endl;
std::cout <<"				|			|				|		" << std::endl;
std::cout <<"|--------|		|-----------------------------------------------------------------------------------|	   |----------|" << std::endl;
std::cout <<"|Sick Bay|--------------|--------------------------Hallway 1------------------------------------------------|------|Radio Room|" << std::endl;
std::cout <<"|--------|		|-----------------------------------------------------------------------------------|	   |----------|" << std::endl;
std::cout <<"				|			|				" <<std::endl;
std::cout <<"				|			|				" <<std::endl;
std::cout <<"				|			|				" <<std::endl;
std::cout <<"				|			|				" <<std::endl;
std::cout <<"			|------------|			|" <<std::endl;
std::cout <<"			|Research Lab|			|" <<std::endl;
std::cout <<"			|------------|			|" <<std::endl;
std::cout <<"							|" <<std::endl;
std::cout <<"							|" <<std::endl;
std::cout <<"|---------|	|------------------------------------------------------------------------------------|		|------|" <<std::endl;
std::cout <<"|Mess Hall|-----|-------------------------------Hallway 2--------------------------------------------|----------|Garage|" <<std::endl;
std::cout <<"|---------|	|------------------------------------------------------------------------------------|		|------|" <<std::endl;
std::cout <<"	|			|			|				|" <<std::endl;
std::cout <<"	|			|			|				|" <<std::endl;
std::cout <<"	|			|			|				|" <<std::endl;
std::cout <<"|-------|			|----------|		|--------|			|---------------|" <<std::endl;
std::cout <<"|Galley |			|Dog Kennel|		|Basement|			|Conference Room|" <<std::endl;
std::cout <<"|-------|			|----------|		|--------|			|---------------|" << std::endl;
}
