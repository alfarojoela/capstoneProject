#pragma once

#include <iostream>
#include <vector>
#include <string>

namespace noun 
{
    std::vector<std::string> getNouns();
    std::string checkCombinedNoun(std::string, std::string);
}