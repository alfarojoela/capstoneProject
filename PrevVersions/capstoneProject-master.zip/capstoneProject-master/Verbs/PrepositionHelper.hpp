#pragma once

#include <iostream>
#include <vector>
#include <string>

namespace preposition 
{
    std::vector<std::string> getPrepositions();
}